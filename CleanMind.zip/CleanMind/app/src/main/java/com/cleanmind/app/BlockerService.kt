package com.cleanmind.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.VpnService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class BlockerService : AccessibilityService() {

    // Lock ke time in apps ke ye screens band
    private val settingsPkgs = setOf("com.android.settings", "com.miui.securitycenter",
        "com.coloros.safecenter", "com.oplus.safecenter", "com.samsung.android.lool")
    private val installerPkgs = setOf("com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller", "com.miui.packageinstaller")
    private val blockedTitles = listOf(
        "accessibility", "additional settings", "device admin", "device administrator",
        "vpn", "private dns", "date & time", "date and time", "install unknown apps",
        "special app access", "installed services", "downloaded apps",
        "एक्सेसिबिलिटी", "अतिरिक्त सेटिंग", "डिवाइस एडमिन"
    )

    // Jin apps me porn keyword scan hoga
    private val watched = setOf(
        "com.android.chrome", "org.mozilla.firefox", "org.mozilla.fenix", "com.sec.android.app.sbrowser",
        "com.microsoft.emmx", "com.brave.browser", "com.opera.browser", "com.opera.mini.native",
        "com.UCMobile.intl", "com.duckduckgo.mobile.android", "com.android.browser",
        "com.mi.globalbrowser", "com.kiwibrowser.browser", "com.vivaldi.browser",
        "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
        "com.google.android.googlequicksearchbox"
    )
    private val keywords = listOf(
        "porn", "xxx", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "brazzers",
        "onlyfans", "hentai", "spankbang", "eporner", "erome", "fapello", "chudai",
        "desi sex", "sex video", "blue film", "camgirl", "adult video", "nude video"
    )

    private var lastScan = 0L
    private var lastVpnCheck = 0L

    override fun onServiceConnected() { ensureVpn() }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        if (Lock.isLocked(this)) {
            ensureVpn()
            if (guardSystemScreens(pkg, event)) return
        }
        if (pkg in watched) scanForPorn()
    }

    private fun guardSystemScreens(pkg: String, event: AccessibilityEvent): Boolean {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return false
        val title = event.text.joinToString(" ").lowercase()
        val cls = event.className?.toString()?.lowercase() ?: ""
        val label = applicationInfo.loadLabel(packageManager).toString().lowercase()

        when {
            pkg == "com.android.vpndialogs" -> return kick("VPN band nahi hoga")
            pkg == "com.android.vending" ->
                if (title.contains("parental controls")) return kick("Lock ke time locked")
            pkg in settingsPkgs || pkg in installerPkgs -> {
                if (blockedTitles.any { title.contains(it) }) return kick("Lock chalu hai")
                val appInfo = title.contains("app info") || cls.contains("appdetails") ||
                        cls.contains("appinfo") || pkg in installerPkgs
                if (appInfo && rootText().contains(label)) return kick("Lock chalu hai")
            }
        }
        return false
    }

    private fun scanForPorn() {
        val now = System.currentTimeMillis()
        if (now - lastScan < 400) return
        lastScan = now
        val text = rootText()
        if (keywords.any { text.contains(it) }) kick("Blocked. Tu strong hai bhai 💪")
    }

    private fun rootText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || count > 400) return
            count++
            n.text?.let { sb.append(it).append(' ') }
            n.contentDescription?.let { sb.append(it).append(' ') }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString().lowercase()
    }

    private fun kick(msg: String): Boolean {
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        return true
    }

    private fun ensureVpn() {
        val now = System.currentTimeMillis()
        if (now - lastVpnCheck < 5000) return
        lastVpnCheck = now
        val wanted = getSharedPreferences("lock", MODE_PRIVATE).getBoolean("vpn_on", false)
        if (wanted && !DnsVpnService.active && VpnService.prepare(this) == null) {
            try { startService(Intent(this, DnsVpnService::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onInterrupt() {}
}
